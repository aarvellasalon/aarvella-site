const hamburger = document.querySelector('.hamburger');
const mobileNav = document.querySelector('.mobile-nav');
const bookingPopup = document.querySelector('.booking-popup');
const closePopupButtons = document.querySelectorAll('.close-popup, .popup-overlay');
const bookingButtons = document.querySelectorAll('.js-book');

if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => {
        mobileNav.classList.toggle('open');
    });
}

bookingButtons.forEach((button) => {
    button.addEventListener('click', () => {
        if (bookingPopup) {
            bookingPopup.classList.add('active');
        }
    });
});

closePopupButtons.forEach((element) => {
    element.addEventListener('click', () => {
        if (bookingPopup) {
            bookingPopup.classList.remove('active');
        }
    });
});
